// UniVault starter. Create a project at https://supabase.com and paste its URL + anon key below.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
let db = null;
const $ = id => document.getElementById(id);
const say = msg => $("status").textContent = msg;
if (window.supabase && SUPABASE_URL.startsWith("https://") && !SUPABASE_ANON_KEY.startsWith("YOUR_")) {
  db = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}
async function auth(mode) {
  if (!db) return say("Supabase setup is still needed. Follow README.md first.");
  const email = $("email").value.trim(), password = $("password").value;
  if (!email || password.length < 6) return say("Enter a valid email and a password of at least 6 characters.");
  const result = mode === "signup" ? await db.auth.signUp({email,password}) : await db.auth.signInWithPassword({email,password});
  say(result.error ? result.error.message : (mode === "signup" ? "Account created. Check your email if confirmation is enabled." : "Logged in successfully."));
}
$("signup").onclick = () => auth("signup");
$("login").onclick = () => auth("login");
$("refresh").onclick = loadLibrary;
$("upload").onclick = uploadPdf;
async function loadLibrary() {
  if (!db) return;
  const {data,error} = await db.from("pdfs").select("id,title,department,semester,course_name,storage_path").eq("status","approved").order("created_at",{ascending:false});
  if (error) { $("libraryNote").textContent = error.message; return; }
  $("library").innerHTML = "";
  for (const item of data || []) {
    const {data:link} = await db.storage.from("course-pdfs").createSignedUrl(item.storage_path,300);
    const div = document.createElement("div"); div.className = "resource";
    const a = document.createElement("a"); a.textContent = item.title || item.course_name || "Course PDF"; a.href = link?.signedUrl || "#"; a.target="_blank"; a.rel="noopener";
    const p = document.createElement("p"); p.className="status"; p.textContent = [item.department,item.semester,item.course_name].filter(Boolean).join(" · ");
    div.append(a,p); $("library").append(div);
  }
  $("libraryNote").textContent = data?.length ? "Approved resources" : "No approved PDFs yet.";
}
async function uploadPdf() {
  if (!db) return say("Supabase setup is still needed. Follow README.md first.");
  const {data:{user}} = await db.auth.getUser();
  if (!user) return say("Please log in before submitting a PDF.");
  const file = $("pdf").files[0];
  if (!file || file.type !== "application/pdf") return say("Choose a PDF file first.");
  const dept=$("department").value.trim(), sem=$("semester").value.trim(), course=$("course").value.trim();
  if (!dept || !sem || !course) return say("Enter department, semester and course name.");
  const path = `${user.id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  say("Uploading PDF…");
  const up = await db.storage.from("course-pdfs").upload(path,file,{contentType:"application/pdf"});
  if (up.error) return say(up.error.message);
  const ins = await db.from("pdfs").insert({owner_id:user.id,title:file.name,department:dept,semester:sem,course_name:course,storage_path:path,status:"pending"});
  say(ins.error ? ins.error.message : "Submitted! Your PDF is pending admin review.");
}
if ("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
